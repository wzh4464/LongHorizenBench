# Evaluation Report: C5-claude-opus-max-long-20260417

**Task**: C5 — ReduceSumV2 custom operator for Ascend NPU (cann-ops, High complexity)
**Config**: Claude Code Opus Max (long prompt)
**Evaluator**: claude-opus-4-6
**Date**: 2026-04-18

---

## 1. File Coverage

**HW files**: 25 | **Generated (in HW list)**: 14 | **Coverage**: 56.0%

### Matched HW Files (14/25)
| # | File | Status |
|---|------|--------|
| 1 | CMakeLists.txt | matched |
| 2 | examples/AclNNInvocationNaive/CMakeLists.txt | matched |
| 3 | examples/AclNNInvocationNaive/gen_data.py | matched |
| 4 | examples/AclNNInvocationNaive/main.cpp | matched |
| 5 | examples/AclNNInvocationNaive/README.md | matched |
| 6 | examples/AclNNInvocationNaive/run.sh | matched |
| 7 | examples/AclNNInvocationNaive/verify_result.py | matched |
| 8 | op_host/reduce_sum_v2.cpp | matched |
| 9 | op_host/reduce_sum_v2_tiling.h | matched |
| 10 | op_kernel/reduce_sum_v2.cpp | matched |
| 11 | op_kernel/reduce_sum_v2_ar.h | matched |
| 12 | op_kernel/reduce_sum_v2_ara.h | matched |
| 13 | op_kernel/reduce_sum_v2_common.h | matched |
| 14 | README.md | matched |

### Missing HW Files (11/25)
| # | File | Impact |
|---|------|--------|
| 1 | op_host/aclnn_reduce_sum_v2.cpp | **CRITICAL** — 228-line aclnn API layer (dtype validation, Cast, Contiguous, ViewCopy) |
| 2 | op_host/aclnn_reduce_sum_v2.h | **CRITICAL** — aclnn API header |
| 3 | op_host/fill.h | HIGH — Fill op helper for empty tensor handling |
| 4 | op_host/op_api_def.h | HIGH — API constants (MAX_SUPPORT_DIMS_NUMS, etc.) |
| 5 | op_host/reduce_sum_v2.h | HIGH — l0op header for ReduceSumV2 dispatch |
| 6 | op_host/reduce_sum_v2_common.h | HIGH — Host-side common utilities (DoFuseAxes, GetAxesData) |
| 7 | op_host/reduce_sum_v2_def.cpp | HIGH — Separate OpDef registration with axes as tensor input |
| 8 | op_host/reduce_sum_v2_proto.cpp | HIGH — Shape inference with ReduceDims templates |
| 9 | op_host/reduce_sum_v2_proto.h | HIGH — Proto header (ReduceDimsWithKeepDims, ReduceDimsWithoutKeepDims) |
| 10 | op_host/reduce_sum_v2_tiling.cpp | **CRITICAL** — 657-line tiling with DoFuseAxes, multi-process AR/ARA, compile info |
| 11 | op_kernel/kernel_utils.h | MEDIUM — Kernel utility functions |

### Extra Files (not in HW list)
docs/ReduceSumV2.md, docs/.gitkeep, examples/.gitkeep, framework/CMakeLists.txt, framework/tf_plugin/*, opp_kernel_aicpu/.gitkeep, tests/st/*, tests/ut/.gitkeep

---

## 2. Semantic Analysis

### 2.1 Architecture Comparison

**GT Architecture** (multi-layer, modular):
- **aclnn API layer** (`aclnn_reduce_sum_v2.cpp/h`): External C API with dtype validation, Cast/Contiguous/ViewCopy pipeline
- **l0op layer** (`reduce_sum_v2.cpp/h`): Internal operator dispatch, AICore support checking
- **OpDef** (`reduce_sum_v2_def.cpp`): Operator definition with `axes` as **tensor input** (supports int32/int64)
- **Proto** (`reduce_sum_v2_proto.cpp/h`): Shape inference via ReduceDims templates, data dependency on axes input
- **Tiling** (`reduce_sum_v2_tiling.cpp/h`): 657-line class-based tiling with DoFuseAxes axis fusion, multi-process (up to 4) AR/ARA patterns, compile info, block/UB/workspace tiling
- **Kernel** (`reduce_sum_v2.cpp`, `_ar.h`, `_ara.h`, `_common.h`, `kernel_utils.h`): Template kernel dispatch

**Generated Architecture** (monolithic, simplified):
- **No aclnn API layer** — entirely missing
- **Monolithic `reduce_sum_v2.cpp`** (364 lines): Combines OpDef + InferShape + TilingFunc in one file
- **`axes` as ListInt attribute** — fundamentally different interface from GT's tensor input
- **Simplified tiling** (~150 lines in TilingFunc): Single-pass outer/reduce/inner decomposition, no DoFuseAxes, no compile info, no multi-process support
- **Kernel**: Similar AR/ARA structure but hardcoded dtype dispatch (float16_t / float only)

### 2.2 Per-File Semantic Analysis

#### CMakeLists.txt
- **GT**: 107 lines, references op_host_aclnnInner, opapi, optiling, opsproto targets with extensive include directories (CANN package paths)
- **GEN**: 34 lines, references op_host_aclnn (wrong target name), optiling, opsproto. Missing opapi/aclnnInner targets, missing include directory declarations
- **Gap**: Significant — would not compile in real CANN build system

#### op_host/reduce_sum_v2.cpp
- **GT**: 72 lines — l0op layer with ReduceSumV2 function dispatching to AICore, using opdev headers
- **GEN**: 364 lines — monolithic file combining OpDef (should be in _def.cpp), InferShape (should be in _proto.cpp), and TilingFunc (should be in _tiling.cpp)
- **Gap**: Fundamental — different purpose and API. GT's reduce_sum_v2.cpp is l0op dispatch; GEN's is everything-in-one

#### op_host/reduce_sum_v2_tiling.h
- **GT**: 150+ lines with nested struct definitions (ReduceSumV2Process with ubInfos/blockA/blockR/blockA1 sub-structs), ReduceSumV2CompileInfo, multi-process tiling data
- **GEN**: 53 lines with flat TilingData (mode, dimNum, outerSize, reduceSize, etc.)
- **Gap**: Major — GT's tiling data structure is far more complex with multi-process support

#### op_kernel/reduce_sum_v2.cpp
- **GT**: Dispatches based on tiling key with multiple dtype specializations via templates
- **GEN**: 104 lines, dispatches on MODE_AR/ARA_CONTIGUOUS/NONCONTIGUOUS but only instantiates float16_t and float
- **Gap**: Moderate — similar pattern but missing bfloat16/int32 support, different tiling key scheme

#### op_kernel/reduce_sum_v2_ar.h
- **GT**: Implements AR pattern with proper AscendC APIs (SetGlobalBuffer, DataCopy, pipe management)
- **GEN**: 148 lines, similar AR pattern with workspace-based partial sums and SyncAll finalization
- **Gap**: Moderate — conceptually correct, element-by-element Finalize loop is inefficient

#### op_kernel/reduce_sum_v2_ara.h
- **GT**: Implements ARA with axis-aware strided access patterns
- **GEN**: 280 lines with two classes (KernelReduceSumV2ARA for non-contiguous, KernelReduceSumV2ARAContiguous for contiguous)
- **Gap**: Moderate — reasonable approach but uses GetPhyAddr() for non-contiguous access which may not be correct in AscendC

#### examples/AclNNInvocationNaive/main.cpp
- **GT**: 241 lines, float32 data, shape [2,3,4], reads from file, includes `../../op_host/aclnn_reduce_sum_v2.h`, uses Finalize cleanup
- **GEN**: 217 lines, float16 data, shape [4,8,16], includes `aclnn_reduce_sum_v2.h` (wrong path), no Finalize function
- **Gap**: Moderate — structurally similar but different test parameters and missing header

#### examples/AclNNInvocationNaive/gen_data.py
- **GT**: Uses torch + tensorflow, float32, shape [2,3,4]
- **GEN**: Uses numpy only, float16, shape [4,8,16]
- **Gap**: Low-moderate — functional equivalent but different parameters

#### examples/AclNNInvocationNaive/verify_result.py
- **GT**: float32 dtype
- **GEN**: float16 dtype
- **Gap**: Low — same logic, different default dtype

#### examples/AclNNInvocationNaive/run.sh
- **GT**: 30 lines, sets env vars, prints pass message (stub)
- **GEN**: 55 lines, sets env vars, runs gen_data.py, cmake build, execute, verify
- **Gap**: Low — GEN is actually more complete

### 2.3 Critical Issues

1. **Operator interface mismatch**: GT defines `axes` as tensor input (supports runtime-determined axes); GEN uses ListInt attribute (compile-time only). This is a fundamental API incompatibility.

2. **Missing aclnn API layer**: The entire external-facing API (`aclnnReduceSumV2GetWorkspaceSize` / `aclnnReduceSumV2`) is absent. Without this, the operator cannot be called through the CANN framework.

3. **Missing tiling.cpp**: The 657-line sophisticated tiling with DoFuseAxes axis fusion, multi-process support, and proper UB/block tiling is replaced by ~150 lines of simple single-pass tiling.

4. **No compile info**: GT uses `ReduceSumV2CompileInfo` populated in TilingPrepare; GEN reads platform info directly in TilingFunc — different execution model.

---

## 3. Scoring

### A. Functional Correctness: 2/5
The code demonstrates understanding of ReduceSumV2 semantics — AR mode for small output/large reduce dimension, ARA mode for large output. Shape inference logic is correct. However, the fundamentally wrong operator interface (axes as attr vs tensor), missing aclnn API layer, and simplified tiling mean the operator would not function correctly in the CANN framework. The monolithic file structure also violates the required build system conventions.

### B. Completeness & Coverage: 2/5
14/25 HW files (56%). The 11 missing files include two critical components: the aclnn API layer (228 lines) and the tiling implementation (657 lines). These represent the bulk of the host-side logic complexity. Extra files (docs, tests, framework plugin) show effort but don't compensate for missing core components.

### C. Behavioral Equivalence: 1/5
The operator interface is fundamentally different (attribute vs tensor axes), making it API-incompatible. The aclnn API pipeline (dtype conversion, Contiguous, Cast, ViewCopy) is entirely absent. The tiling produces different data structures. The kernel dispatch uses different tiling keys. Only the high-level reduction concept (outer/reduce/inner decomposition with AR/ARA modes) matches the GT approach.

### Verdict: **PARTIAL**
A=2, B=2, C=1. Does not meet PASS criteria (A≥4 AND B≥4 AND C≥3). Does not meet FAIL criteria (A≤1). Therefore: PARTIAL.

---

## 4. Summary

The agent correctly identified the need for a ReduceSumV2 operator with AR/ARA tiling modes and created a reasonable directory structure. However, it took a fundamentally different architectural approach — monolithic instead of modular, attribute-based axes instead of tensor input, and no aclnn API layer. The 11 missing HW files (44% of required files) include the two most complex host-side components. The result is a conceptually aligned but practically incompatible implementation.
