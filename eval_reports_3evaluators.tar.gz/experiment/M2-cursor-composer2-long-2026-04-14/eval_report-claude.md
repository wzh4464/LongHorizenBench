# Evaluation Report

**Task**: M2 (MindSpeed — reset-bucket-group-order)
**Config**: cursor-composer2-long
**Evaluator**: claude-opus-4-6
**Date**: 2026-04-18

---

## 1. File Coverage

| Metric | Value |
|--------|-------|
| HW files (GT) | 6 |
| Gen files | 7 |
| Covered (exact path match) | 3 |
| HW-file coverage | 3/6 = **50.0%** |

**Covered files:**
- `docs/features/reset-bucket-group-order.md`
- `mindspeed/features_manager/__init__.py`
- `mindspeed/features_manager/distributed/reset_bucket_group_order_feature.py`

**Missed HW files:**
- `mindspeed/core/distributed/reset_bucket_group_order_feature/__init__.py`
- `mindspeed/core/distributed/reset_bucket_group_order_feature/distributed_data_parallel.py`
- `mindspeed/core/distributed/reset_bucket_group_order_feature/distributed_data_parallel_config.py`

**Extra gen files (not in HW):**
- `mindspeed/core/distributed/bucket_group_order/__init__.py`
- `mindspeed/core/distributed/bucket_group_order/ddp_config_adaptor.py`
- `mindspeed/core/distributed/bucket_group_order/ddp_init_adaptor.py`
- `tests_extend/unit_tests/test_bucket_group_order.py`

**Note:** The agent created functionally analogous core files under `bucket_group_order/` instead of `reset_bucket_group_order_feature/`. The 3 missed HW files have semantic equivalents in the gen output (different directory, different filenames).

---

## 2. Function Coverage

| Metric | Value |
|--------|-------|
| GT functions | 10 |
| Gen functions | 20 |
| Covered (exact name) | 7 |
| Function coverage | 7/10 = **70.0%** |

**Covered:** `__init__`, `distributed_data_parallel_init_wrapper`, `register_args`, `register_patches`, `ResetBucketGroupOrderFeature`, `validate_args`, `wrapper`

**Missed GT functions:**
- `_make_forward_pre_hook` — GT's core runtime recording hook; agent used a completely different static approach
- `hook` — inner function of `_make_forward_pre_hook`; not applicable in gen approach
- `distributed_data_parallel_config_init_wrapper` — agent has semantic equivalent: `distributed_data_parallel_config_reset_bucket_order_wrapper`

**Extra gen functions (notable):**
- `_param_first_module_index` — static module-tree analysis helper
- `_relink_param_gather_chain` — chain rebuild helper
- `reorder_bucket_groups_by_module_order` — core static reorder logic
- `test_reorder_bucket_groups_follows_module_order` — unit test (not in GT)

---

## 3. Qualitative Analysis

### Core Algorithm Difference

This is the most significant divergence between GT and generated code:

| Aspect | Ground Truth | Generated |
|--------|-------------|-----------|
| **When** | After 1st forward iteration (runtime) | At DDP `__init__` time (static) |
| **How** | Records actual bucket group visit order during forward pre-hooks in 1st iteration, then relinks chain | Infers order from `module.modules()` DFS traversal, sorts by min parameter module index |
| **Patches** | Config `__init__` + DDP `__init__` + `_make_forward_pre_hook` (3 patches) | Config `__init__` + DDP `__init__` (2 patches) |
| **Accuracy** | Captures actual runtime forward execution order | Heuristic; may not match actual forward order when control flow diverges from module tree |

The GT approach (`_make_forward_pre_hook`) hooks into the forward pass to record the actual order in which bucket groups are accessed, then reorders the `next_param_gather_bucket_group` chain after the first complete forward pass. This is the "gold standard" approach because it observes real execution.

The gen approach uses `module.modules()` DFS order as a proxy for forward execution order. While this is a well-known approximation (PyTorch's own DDP uses registration order), it may fail in the exact scenarios this feature targets — models where module definition order diverges from forward execution order (multimodal, re-wrapped transformers).

The gen code's own documentation acknowledges this limitation: "排序键基于模块树遍历顺序，与严格意义上的动态 forward 路径在存在控制流或重复访问时可能仍有偏差".

### Structural Integration

Both approaches follow MindSpeed's Feature pattern correctly:
- ✅ `MindSpeedFeature` subclass with `register_args`, `validate_args`, `register_patches`
- ✅ CLI argument `--reset-bucket-group-order` with `action='store_true'`
- ✅ Validation: requires `--overlap-param-gather`
- ✅ Registration in `features_manager/__init__.py` → `add_distributed_features()`
- ✅ Documentation in `docs/features/`

### Patch Path Differences

| Component | GT Path | Gen Path |
|-----------|---------|----------|
| DDP Config | `megatron.core.distributed.distributed_data_parallel_config.DistributedDataParallelConfig.__init__` | `megatron.core.distributed.DistributedDataParallelConfig.__init__` |
| DDP Init | `megatron.core.distributed.distributed_data_parallel.DistributedDataParallel.DistributedDataParallel.__init__` (has doubled class name) | `megatron.core.distributed.distributed_data_parallel.DistributedDataParallel.__init__` |
| Forward Hook | `megatron.core.distributed.distributed_data_parallel.DistributedDataParallel._make_forward_pre_hook` | (not patched) |

Note: The GT has a potential bug in its DDP init patch path (`DistributedDataParallel.DistributedDataParallel.__init__` — doubled class name).

### Documentation Quality

The gen documentation (52 lines) is significantly more detailed than GT (30 lines), covering background, applicable scenarios, implementation details, configuration, expected effects, and caveats. Quality is high.

### Extra: Unit Test

The gen includes `tests_extend/unit_tests/test_bucket_group_order.py` with a mock-based test verifying reorder logic. GT has no tests.

---

## 4. Scores

### A. Functional Correctness: **3/5**

The code implements a working bucket group reorder feature that integrates correctly into MindSpeed's Feature framework. The CLI interface, validation, and structural integration are all correct. However, the core algorithm (static module-tree heuristic) differs fundamentally from the GT (runtime forward-order recording). The static approach is a reasonable approximation but may not solve the problem in the exact target scenarios (models with mismatched definition/execution order) — which is the primary motivation for this feature.

### B. Completeness & Coverage: **3/5**

All structural components are present: Feature class, CLI args, validation, config patch, DDP init patch, documentation, and features_manager registration. However:
- File coverage is 50% (different directory structure for core files)
- The GT's key innovation — `_make_forward_pre_hook` modification for runtime order recording — is entirely absent
- The agent adds unit tests (bonus, not in GT)

### C. Behavioral Equivalence: **2/5**

Same external interface (CLI flag, activation conditions), but the internal behavior diverges significantly:
- GT reorders after observing actual 1st-iteration forward order; Gen reorders at init from module tree
- For simple models (DFS order ≈ forward order), behavior would be similar
- For complex models (the target use case), reorder results could differ substantially
- GT patches 3 entry points; Gen patches 2 (no forward hook modification)

---

## 5. Verdict: **PARTIAL**

The agent successfully scaffolded the entire feature following MindSpeed conventions (Feature class, CLI, validation, documentation, registration). The code would compile and run. However, the core reordering algorithm differs fundamentally from the ground truth — using a static heuristic instead of runtime profiling — which may not work correctly for the exact use cases the feature is designed to address.
