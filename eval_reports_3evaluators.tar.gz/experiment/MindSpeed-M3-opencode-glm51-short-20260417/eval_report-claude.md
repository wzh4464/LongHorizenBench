# Evaluation Report: MindSpeed-M3-opencode-glm51-short-20260417

**Evaluator**: claude-opus-4-6
**Task**: M3 (MindSpeed — High complexity, Python)
**Config**: opencode-glm51-short
**Date**: 2026-04-18

---

## 1. File Coverage

| # | GT (Handwritten) File | GEN File | Match |
|---|----------------------|----------|-------|
| 1 | `docs/features/compress-dense.md` | *(not created)* | MISS |
| 2 | `docs/features/compress-tensor.md` | *(not created)* | MISS |
| 3 | `mindspeed/core/memory/compress/adaptor.py` | `mindspeed/core/memory/memory_compress/adaptor.py` | PATH-DIFF |
| 4 | `mindspeed/core/memory/compress/compress_activation.py` | `mindspeed/core/memory/memory_compress/activation_compress.py` | PATH-DIFF |
| 5 | `mindspeed/core/memory/compress/compress_optimizer.py` | `mindspeed/core/memory/memory_compress/optimizer_state_compress.py` | PATH-DIFF |
| 6 | `mindspeed/core/memory/compress/utils.py` | *(not created)* | MISS |
| 7 | `mindspeed/features_manager/__init__.py` | `mindspeed/features_manager/__init__.py` | EXACT |
| 8 | `mindspeed/features_manager/compress/__init__.py` | `mindspeed/features_manager/memory_compress/__init__.py` | PATH-DIFF |
| 9 | `mindspeed/features_manager/compress/compress.py` | `mindspeed/features_manager/memory_compress/memory_compress_feature.py` | PATH-DIFF |

**Exact path matches**: 1/9 (11.1%)
**Functional equivalents (different path)**: 5/9
**Missing entirely**: 3/9 (docs × 2, utils.py)

---

## 2. Function / Class Coverage

### GT key classes & functions → GEN mapping

| GT Symbol | GEN Equivalent | Semantic Match |
|-----------|---------------|----------------|
| `GlobalContext` | *(none — no equivalent)* | MISS |
| `GlobalContextConfig` | *(none)* | MISS |
| `ContextState` | *(none)* | MISS |
| `LayerActivationManager` | `LayerActivationCompressManager` | PARTIAL — manages per-layer hooks, but no stream-based async compress/decompress |
| `CompressHook(saved_tensors_hooks)` | `ActivationCompressHook` | PARTIAL — uses pack/unpack hooks but via bf16 casting, not NPU lossless ops |
| `TensorManager` | `_CompressedTensor` | PARTIAL — stores compressed state, but no NPU encode/decode |
| `TensorState` | *(none)* | MISS |
| `ShareMemory` | *(none)* | MISS |
| `ListNode` | *(none)* | MISS |
| `SimulationBase` / `SimulationA2` / `SimulationA3` | *(none)* | MISS |
| `SimulationHyperParams` | *(none)* | MISS |
| `CompressTensor` | *(none)* | MISS |
| `CompressActivationFeature` | `MemoryCompressFeature` (combined) | PARTIAL — single feature, different CLI args |
| `CompressOptimizerFeature` | `MemoryCompressFeature` (combined) | PARTIAL — merged into single feature |
| `compress_adamw_impl` | `OptimizerStateCompressor` | PARTIAL — different approach (bf16 wrapping vs npu_apply_adam_w) |
| `compress_optimizer_step` / `compress_optimizer_step_impl` | `optimizer_step_wrapper` | PARTIAL — wraps step but different mechanism |
| `layer_forward_wrapper` | `transformer_layer_forward_wrapper` | PARTIAL — wraps forward, but no UUID ordering, no async compression |
| `backward_start` | *(none)* | MISS |
| `get_global_context` | `get_compress_manager` | WEAK |
| `get_statistic` / `get_moe_average_token_num` / `get_absolute_order` | *(none)* | MISS |
| `filter_func` | *(none)* | MISS |
| `get_swap_tensor` | *(none)* | MISS |
| `infer_matmul_shape` | *(none)* | MISS |

**Approximate function coverage**: ~8/35 key symbols have any GEN equivalent → ~23%

---

## 3. Semantic / Behavioral Analysis

### 3a. Activation Compression

**GT approach**: 
- Uses NPU hardware-accelerated lossless compression via `torch_npu.npu_hans_encode` / `npu_hans_decode`
- Multi-stream async compression (vice_stream for compression, default_stream for compute)
- Global context manages layer ordering with UUID-based linked list (`ListNode`)
- Compression happens during matmul/allgather/all2all via operator wrapping (`_wrapper_async_func`)
- Time-cost simulation model (`SimulationBase`) determines how many tensors to compress per async window
- `--compress-activation` accepts layer ranges (e.g., `1-3,5-8,10` or `0` for all)

**GEN approach**:
- Uses simple bf16 downcasting with residual (lossy, not hardware-accelerated)
- No multi-stream async — synchronous `saved_tensors_hooks` pack/unpack
- No operator wrapping, no time-cost simulation
- No layer-range selection — boolean on/off via `--memory-compress-activation`
- CPU swap path via `pin_memory()` + `.cpu()` (basic, not NPU-native swap)

**Verdict on activation compression**: Fundamentally different mechanism. GT uses NPU lossless compression with async multi-stream scheduling; GEN uses naive bf16 cast with optional CPU offload. The GEN approach would NOT produce equivalent behavior — it introduces precision loss that GT avoids, and lacks the performance-critical async scheduling.

### 3b. Optimizer State Compression

**GT approach**:
- Custom `CompressTensor` class wrapping `TensorManager` with NPU encode/decode
- Replaces `AdamW.step()` with `compress_optimizer_step_impl` that uses `torch_npu.npu_apply_adam_w`
- PDF-based statistic tracking for adaptive compression
- Direct integration with MindSpeed's custom AdamW

**GEN approach**:
- `OptimizerStateCompressor` compresses exp_avg/exp_avg_sq to bf16 with residual
- Wraps optimizer step to decompress before, compress after
- No NPU-native operations, no PDF statistics

**Verdict on optimizer compression**: Different mechanism. GT uses NPU hardware lossless compression with custom AdamW fusion; GEN uses bf16 approximation.

### 3c. Feature Registration (`__init__.py`)

**GT**: Adds `CompressActivationFeature` and `CompressOptimizerFeature` as separate features via `add_compress_memory_feature()`, imported from `mindspeed.features_manager.compress.compress`.

**GEN**: Adds single `MemoryCompressFeature` via `add_memory_compress_features()`, imported from `mindspeed.features_manager.memory_compress.memory_compress_feature`.

**Verdict**: Structurally similar (both register in `create_features_list`), but different decomposition and wrong import paths.

### 3d. CLI Arguments

**GT**: `--compress-activation <layer-range>` (string, layer selection), `--compress-optimizer` (boolean flag)
**GEN**: `--memory-compress-activation` (boolean), `--memory-compress-optimizer <disable|level0|level1>` (string), plus `--memory-compress-ratio` and `--memory-compress-activation-swap`

**Verdict**: Incompatible CLI interface. GT args won't parse with GEN code and vice versa.

### 3e. Documentation

**GT**: Replaces `docs/features/compress-dense.md` with new `docs/features/compress-tensor.md` documenting all three compression features.
**GEN**: No documentation files created.

---

## 4. Scoring

### A. Functional Correctness: 1 / 5

The agent understood the task domain (memory compression for activations and optimizer states) and created a plausible module structure. However:
- The core compression mechanism is fundamentally wrong: bf16 casting vs NPU lossless compression
- No `torch_npu.npu_hans_encode/decode` usage — the central algorithm is absent
- No async multi-stream scheduling — the key performance innovation is missing
- No operator wrapping (matmul/allgather/all2all) for async overlap
- No time-cost simulation model
- CLI args are incompatible with GT
- The code would not pass functional tests in the actual MindSpeed environment

### B. Completeness & Coverage: 1 / 5

- 1/9 exact file path match; 3/9 files entirely missing
- ~23% function-level coverage (and those are weak/partial matches)
- Missing entire subsystems: `utils.py` (TensorManager, ShareMemory, ListNode, Simulation classes), documentation
- Two GT features collapsed into one, with wrong argument names
- No binary image file (`compress_activation_coloured.png`)

### C. Behavioral Equivalence: 0 / 5

- The compression is lossy (bf16) vs GT's lossless (NPU hardware)
- No async scheduling means no performance overlap with compute
- No layer-range selection for activation compression
- Optimizer compression doesn't use NPU fused AdamW
- The generated code would produce different numerical results, different performance characteristics, and different memory savings
- CLI arguments are entirely incompatible

---

## 5. Summary

| Dimension | Score |
|-----------|-------|
| A. Functional Correctness | 1 |
| B. Completeness & Coverage | 1 |
| C. Behavioral Equivalence | 0 |

**Verdict: FAIL**

The agent recognized the high-level task (activation + optimizer compression for MindSpeed) and created a reasonable module skeleton with the correct `MindSpeedFeature` registration pattern. However, the implementation substitutes a naive bf16-casting approach for the GT's NPU hardware-accelerated lossless compression with async multi-stream scheduling. This is not a minor deviation — the entire algorithmic core is different, the CLI interface is incompatible, and the behavioral output would diverge significantly. The missing `utils.py` means critical infrastructure (TensorManager, ShareMemory, ListNode, Simulation models) that GT heavily depends on is absent entirely.
