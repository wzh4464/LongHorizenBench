# Evaluation Report: C4-cursor-composer2-long-2026-04-14

- **Task**: C4 — Implement Exp custom operator for Ascend NPU
- **Config**: Cursor Composer 2
- **Prompt**: long
- **Evaluator**: claude-opus-4-6
- **Date**: 2026-04-18

---

## 1. File Coverage

**HW files**: 19  
**Generated files (code only)**: 12  
**Overlap**: 11  
**Coverage**: 11 / 19 = **57.9%**

### Present (11/19)
| # | File | Status |
|---|------|--------|
| 1 | `src/contrib/math/exp/CMakeLists.txt` | ✅ Present |
| 2 | `src/contrib/math/exp/docs/Exp.md` | ✅ Present (abbreviated) |
| 3 | `src/contrib/math/exp/examples/AclNNInvocationNaive/CMakeLists.txt` | ✅ Present |
| 4 | `src/contrib/math/exp/examples/AclNNInvocationNaive/README.md` | ✅ Present (abbreviated) |
| 5 | `src/contrib/math/exp/examples/AclNNInvocationNaive/gen_data.py` | ✅ Present |
| 6 | `src/contrib/math/exp/examples/AclNNInvocationNaive/main.cpp` | ✅ Present |
| 7 | `src/contrib/math/exp/examples/AclNNInvocationNaive/run.sh` | ✅ Present |
| 8 | `src/contrib/math/exp/examples/AclNNInvocationNaive/verify_result.py` | ✅ Present |
| 9 | `src/contrib/math/exp/op_host/exp.cpp` | ✅ Present |
| 10 | `src/contrib/math/exp/op_host/exp_tiling.h` | ✅ Present |
| 11 | `src/contrib/math/exp/op_kernel/exp.cpp` | ✅ Present |

### Missing (8/19)
| # | File | Category |
|---|------|----------|
| 1 | `src/contrib/math/exp/README.md` | Documentation |
| 2 | `src/contrib/math/exp/framework/CMakeLists.txt` | Framework adapter |
| 3 | `src/contrib/math/exp/framework/tf_plugin/CMakeLists.txt` | Framework adapter |
| 4 | `src/contrib/math/exp/framework/tf_plugin/tensorflow_exp_plugin.cc` | Framework adapter |
| 5 | `src/contrib/math/exp/tests/st/Exp_case_alltype.json` | ST test suite |
| 6 | `src/contrib/math/exp/tests/st/msopst.ini` | ST test suite |
| 7 | `src/contrib/math/exp/tests/st/README.md` | ST test suite |
| 8 | `src/contrib/math/exp/tests/st/test_exp.py` | ST test suite |

### Extra (1 file not in GT)
- `src/contrib/math/exp/tests/test_exp_reference.py` — NumPy-based pytest reference tests (useful addition)

---

## 2. Function-Level Coverage

### op_host/exp.cpp — Host implementation
| Function/Entity | GT | GEN | Match |
|---|---|---|---|
| `optiling::TilingFunc` | ✅ UB split, big/small core, base→log, tiling key 0/1 | ✅ UB split, big/small core, dtype-based tiling key 1/2/3, RoundUp/Down helpers | Equivalent (different tiling key scheme) |
| `ge::InferShape` | ✅ output = input shape | ✅ Same | ✓ |
| `ge::InferDataType` | ✅ Defined but not bound via SetInferDataType | ✅ Defined AND bound via SetInferDataType | GEN is better |
| `ops::Exp` class | ✅ Input x, Output y, Attrs base/scale/shift, ascend910b | ✅ Identical spec | ✓ |

### op_host/exp_tiling.h — Tiling data
| Field | GT | GEN |
|---|---|---|
| Core/tile sizing | uint64_t: smallCoreDataNum, bigCoreDataNum, ubPartDataNum, etc. | uint32_t: smallBlockLength, bigBlockLength, smallTileLength, etc. |
| Attributes | float: base, scale, shift | float: scale, shift, preExpLog (pre-computed ln(base)) |
| Registration | REGISTER_TILING_DATA_CLASS(Exp, ExpTilingData) | Same | 

Different field names and types but semantically equivalent. GEN pre-computes ln(base) on host (preExpLog) rather than passing raw base.

### op_kernel/exp.cpp — Kernel implementation
| Component | GT | GEN | Match |
|---|---|---|---|
| Architecture | Template class `KernelExp<TYPE_X, TYPE_Y, IsExistBigCore>` + macro dispatch | 3 separate classes: KernelExpFp16, KernelExpFp32, KernelExpBf16 | Equivalent |
| Computation | Muls(scale) → Adds(shift) → Muls(base) → Exp | Muls(scale) → Adds(shift) → Muls(preExpLog) → Exp | ✓ Identical pipeline |
| BF16 handling | Cast bf16→float, compute, Cast float→bf16 | Same | ✓ |
| CopyIn/Compute/CopyOut pipeline | ✅ | ✅ | ✓ |
| Big/small core split | Template bool IsExistBigCore | Runtime if/else on bigDataCoreNum | Equivalent |
| Copy-paste artifacts | `reciprocal_do` function left in | None | GEN is cleaner |

### Example files
| File | GT | GEN | Match |
|---|---|---|---|
| main.cpp | shape [10,10], base=2.0, scale=2.0, shift=1.0 | shape [32], base=-1.0, scale=0.5, shift=0.25 | Functionally equivalent, different params |
| gen_data.py | shape [10,10], same params as main | shape [32], matches GEN main | ✓ (internally consistent) |
| verify_result.py | Custom abs/rel tolerance check | np.allclose-based | ✓ |
| run.sh | Standard build+run script | Same structure | ✓ |
| CMakeLists.txt | Standard cmake | Same | ✓ |

---

## 3. Semantic Analysis

### Strengths
1. **Core algorithm correct**: The computation pipeline (scale·x + shift, multiply by ln(base), exp) is correctly implemented in both host and kernel, matching GT semantics exactly.
2. **All three data types supported**: float16, float32, bfloat16 all handled correctly. BF16 correctly upcast to float for computation.
3. **Tiling logic sound**: Big/small core splitting, UB partitioning, and data alignment all implemented correctly with proper edge case handling.
4. **Cleaner than GT in some aspects**: No copy-paste artifacts (GT has `reciprocal_do` residue), proper `SetInferDataType` binding, explicit error handling via `ResolvePreExpLog`.
5. **Example is internally consistent**: gen_data.py parameters match main.cpp constants.
6. **Extra value**: Added `test_exp_reference.py` with parameterized pytest tests covering multiple base/scale/shift combinations.

### Weaknesses
1. **Missing entire TF framework adapter** (3 files): `framework/CMakeLists.txt`, `tf_plugin/CMakeLists.txt`, `tensorflow_exp_plugin.cc`. This means the operator cannot be auto-mapped from TensorFlow graphs.
2. **Missing entire ST test suite** (4 files): `Exp_case_alltype.json`, `msopst.ini`, `test_exp.py`, `README.md`. The standard msOpST-based hardware testing infrastructure is absent.
3. **Missing root README.md**: No top-level operator documentation for users.
4. **Different tiling key semantics**: GT uses keys 0/1 for big-core/no-big-core; GEN uses keys 1/2/3 for dtype dispatch. Both are valid AscendC patterns but they are architecturally different. If the CANN build system expects a specific tiling key convention, this could cause issues.
5. **Documentation much sparser**: Exp.md is ~20 lines vs GT's 83 lines. Missing API parameter descriptions, return codes, constraint details.
6. **Example uses different test parameters**: While internally consistent, the different shape [32] vs [10,10] and different base/scale/shift values mean the example doesn't demonstrate the same configuration as GT.

### Behavioral Differences
- The operator would compute the same mathematical result for all inputs/dtypes.
- The tiling strategy produces equivalent data partitioning (big/small core split with UB buffering).
- The example demonstrates a valid but different parameter configuration (natural base, scale=0.5, shift=0.25 vs base=2.0, scale=2.0, shift=1.0).

---

## 4. Scoring

### A. Functional Correctness: **3 / 5**
The core Exp operator (host definition + tiling + kernel computation) is correctly implemented and would produce correct results for all supported dtypes (float16, float32, bfloat16) with arbitrary base/scale/shift parameters. The computation pipeline exactly matches the specification: y = base^(scale·x + shift). However, 42% of required deliverables are missing (framework adapter, ST tests, root README), reducing the completeness of the functional delivery. The operator itself works, but the full task deliverable is incomplete.

### B. Completeness & Coverage: **2 / 5**
File coverage is 11/19 (57.9%). Two entire categories are completely absent:
- TF framework adapter (blocks TF graph auto-mapping)
- ST test suite (blocks hardware validation)
The root README is also missing. While the core operator files are all present and the extra pytest reference test adds value, the missing categories represent significant gaps in the expected deliverable structure.

### C. Behavioral Equivalence: **2 / 5**
For the 11 present files, behavioral equivalence with GT is high — the computation logic, operator definition, and example structure all match GT semantics. However, there are notable architectural differences (tiling key scheme, separate kernel classes vs template, uint32_t vs uint64_t tiling fields) and 8 files are entirely absent. The documentation is much sparser. The example uses different (though valid) test parameters. Weighted across all 19 required files, behavioral equivalence is moderate.

### Verdict: **PARTIAL**
- A=3 (not ≥4), B=2 (not ≥4), C=2 (not ≥3) → does not meet PASS criteria
- A=3 (not ≤1) → not FAIL
- Result: **PARTIAL**

| Dimension | Score |
|-----------|-------|
| A. Functional Correctness | 3 |
| B. Completeness & Coverage | 2 |
| C. Behavioral Equivalence | 2 |
| **Verdict** | **PARTIAL** |
