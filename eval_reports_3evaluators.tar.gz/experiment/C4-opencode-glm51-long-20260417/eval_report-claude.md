# Evaluation Report: C4-opencode-glm51-long-20260417

**Task**: C4 — Implement Exp operator for Ascend NPU (CANN cann-ops)
**Config**: opencode-glm51 (OpenCode + GLM-5.1)
**Prompt**: C4-long
**Evaluator**: claude-opus-4-6
**Date**: 2026-04-18

---

## 1. File Coverage

**HW files**: 19 | **Generated (matching HW)**: 17 | **Coverage**: 17/19 = **89.5%**

### Missing Files (2)
| File | Impact |
|------|--------|
| `examples/AclNNInvocationNaive/README.md` | Documentation only |
| `tests/st/README.md` | Documentation only |

### Extra Files (non-HW)
- `opp_kernel_aicpu/.gitkeep`, `tests/ut/.gitkeep` (scaffold placeholders, harmless)

---

## 2. Per-File Semantic Analysis

### 2.1 CMakeLists.txt (top-level)
**Match: Excellent.** Identical structure to GT — `add_ops_compile_options(Exp)`, correct `target_sources`, `target_include_directories`, `install` directives. Functionally equivalent.

### 2.2 README.md (top-level)
**Match: Good.** Generated provides a more technical README with operator formulas, spec table, and constraint section. GT has standard boilerplate structure with directory tree and build instructions. Different style but both valid project READMEs.

### 2.3 docs/Exp.md
**Match: Good.** Both describe the Exp operator with supported dtypes, implementation principle, and API interfaces. Generated includes the full `base/scale/shift` formula and describes the aclnn API with base/scale/shift as explicit parameters. GT's aclnn interface signature is simpler (no base/scale/shift params) but GT's own main.cpp contradicts this by passing those params. Generated is internally consistent.

### 2.4 examples/AclNNInvocationNaive/CMakeLists.txt
**Match: Excellent.** Nearly identical — same project name `acl_execute_exp`, same libraries, same structure. Minor whitespace differences only.

### 2.5 examples/AclNNInvocationNaive/gen_data.py
**Match: Partial.** GT generates shape `[10,10]` data with custom `base=2.0, scale=2.0, shift=1.0` and includes a full `exp()` function handling base/scale/shift. Generated uses shape `[1024]` with simple `np.exp(x)` (default natural exp only). Generated does not test custom base/scale/shift parameters in data generation.

### 2.6 examples/AclNNInvocationNaive/main.cpp
**Match: Good.** Both follow the same AscendC single-op execution pattern (ReadFile, WriteFile, Init, CreateAclTensor, two-stage aclnn call). Key difference: GT passes `aclnnExpGetWorkspaceSize(inputX, 2.0f, 2.0f, 1.0f, outputY, ...)` while generated passes `(inputX, -1.0f, 1.0f, 0.0f, outputY, ...)` (default params). Shape differs (`{10,10}` vs `{1024}`). Structure is equivalent.

### 2.7 examples/AclNNInvocationNaive/run.sh
**Match: Excellent.** Same environment setup, build, and verification flow. Minor differences (generated adds `#!/bin/bash` shebang, `rm -f` instead of `rm`).

### 2.8 examples/AclNNInvocationNaive/verify_result.py
**Match: Excellent.** Essentially identical tolerance-checking logic with same constants (LOSS=1e-3, MINIMUM=10e-10).

### 2.9 framework/CMakeLists.txt
**Match: Exact.** Identical content.

### 2.10 framework/tf_plugin/CMakeLists.txt
**Match: Excellent.** Same build targets and install destinations. Trivial formatting differences.

### 2.11 framework/tf_plugin/tensorflow_exp_plugin.cc
**Match: Excellent.** Both register "Exp" op with TENSORFLOW framework type via `AutoMappingByOpFn`. Different license header only.

### 2.12 op_host/exp.cpp (CRITICAL)
**Match: Partial — functional but divergent implementation.**

Similarities:
- Both implement TilingFunc with UB-based data partitioning, big/small core dispatch
- Both read base/scale/shift attributes from RuntimeAttrs
- Both register Exp op with `DT_FLOAT16, DT_FLOAT, DT_BF16`, `FORMAT_ND`
- Both implement InferShape (output shape = input shape)

Differences:
| Aspect | GT | Generated |
|--------|----|----|
| UB partition for BF16 | `ubPartNum=3` (input+output+cast) | `ubDataNumber=4` (input+output+2 calc bufs) |
| UB partition for float16 | `ubPartNum=2` | `ubDataNumber=4` (allocates unnecessary calc bufs) |
| Tiling field types | `uint64_t` | `uint32_t` |
| base handling | Stores processed base (`1.0` for default, `log(base)` for positive) | Stores raw `base` + separate `logBase` field |
| Core dispatch | `SetTilingKey(0/1)` for compile-time template dispatch | Runtime `if(coreNum < tailBlockNum)` in kernel |
| InferDataType | Defined | **Missing** |

The generated version's UB sizing is more conservative (allocates 2 extra float buffers for float16, which the GT avoids). This wastes memory for float16 but doesn't cause correctness issues. The `logBase` separation is a cleaner design than GT's in-place base overwriting.

### 2.13 op_host/exp_tiling.h (CRITICAL)
**Match: Partial — different field set.**

| GT Fields | Generated Fields |
|-----------|-----------------|
| `uint64_t smallCoreDataNum` | `uint32_t smallCoreDataNum` |
| `uint64_t bigCoreDataNum` | `uint32_t bigCoreDataNum` |
| `uint64_t ubPartDataNum` | `uint32_t tileDataNum` |
| `uint64_t smallCoreTailDataNum` | `uint32_t smallTailDataNum` |
| `uint64_t bigCoreTailDataNum` | `uint32_t bigTailDataNum` |
| `uint64_t smallCoreLoopNum` | `uint32_t finalSmallTileNum` |
| `uint64_t bigCoreLoopNum` | `uint32_t finalBigTileNum` |
| `uint64_t tailBlockNum` | `uint32_t tailBlockNum` |
| `float base, scale, shift` | `float base, scale, shift, logBase` |

Different names and types but semantically equivalent fields. Generated adds `logBase` for cleaner base handling. `uint32_t` is sufficient for typical tensor sizes.

### 2.14 op_kernel/exp.cpp (CRITICAL)
**Match: Partial — different architecture, same algorithm.**

| Aspect | GT | Generated |
|--------|----|----|
| Class design | Templated `KernelExp<TYPE_X, TYPE_Y, IsExistBigCore>` | Non-templated `KernelExp` with DTYPE_X macros |
| Kernel entry | `exp(...)` | `exp_custom(...)` — **name mismatch** |
| Dispatch | `TILING_KEY_IS(0/1)` → compile-time template | Runtime `if` in Init |
| float16 compute | Direct float16 Muls/Adds/Exp | Cast to float32, compute, cast back |
| BF16 cast rounding | `CAST_RINT` | `CAST_ROUND` |
| Extra | `reciprocal_do` copy-paste bug from reciprocal op | Clean, no artifacts |
| Code quality | Macro-heavy (GENERAL_OP_IMPL) | Cleaner ComputeFloat helper |

The generated kernel name `exp_custom` vs GT's `exp` is a potential binding issue at runtime. The generated code is arguably cleaner (no copy-paste bugs, better abstraction) but uses a different name convention.

### 2.15 tests/st/Exp_case_alltype.json
**Match: Good.** Generated has 2 test cases (default params + custom base=2.0/scale=0.5/shift=1.0) vs GT's single case (base=2.0/scale=1.0/shift=2.0). Shape differs ([1024] vs [100]). Generated provides more comprehensive test coverage.

### 2.16 tests/st/msopst.ini
**Match: Excellent.** Same configuration values. Generated is more concise (fewer comments).

### 2.17 tests/st/test_exp.py
**Match: Partial but generated is more correct.**

GT version has bugs:
- Missing `import math` (will fail at runtime)
- `exp_test()` computes `scale*x + shift` but never applies `np.exp()` — incorrect reference output
- Uses TensorFlow dependency unnecessarily

Generated version:
- Uses numpy only (simpler, correct dependencies)
- Correctly applies `np.power(base, exponent)` for positive base and `np.exp(exponent)` for default
- Different function signature (`calc_expect_func` includes `y` parameter)

---

## 3. Function Coverage (Critical Files)

### op_host/exp.cpp
| Function | GT | Generated |
|----------|:--:|:---------:|
| TilingFunc | Y | Y |
| InferShape | Y | Y |
| InferDataType | Y | **N** |
| Exp::OpDef constructor | Y | Y |

### op_kernel/exp.cpp
| Function | GT | Generated |
|----------|:--:|:---------:|
| KernelExp::Init | Y | Y |
| KernelExp::Process | Y | Y |
| KernelExp::CopyIn | Y | Y |
| KernelExp::Compute | Y | Y (via ComputeFloat) |
| KernelExp::CopyOut | Y | Y |
| Kernel entry (`exp`/`exp_custom`) | Y | Y (different name) |

---

## 4. Scoring

### A. Functional Correctness: 3/5
The core algorithm is correctly implemented: tiling strategy follows AscendC patterns, kernel implements correct CopyIn→Compute→CopyOut pipeline, base/scale/shift math is correct, all 3 dtypes (float16/float32/bfloat16) are handled. However: (1) kernel entry point named `exp_custom` vs GT's `exp` — potential runtime binding failure; (2) float16 unnecessarily casts to float32 (wastes UB, may affect precision); (3) missing InferDataType; (4) different UB sizing heuristic could cause edge-case issues.

### B. Completeness & Coverage: 4/5
17/19 HW files present (89.5%). Missing files are both README documentation (non-functional). All critical code files (op_host, op_kernel, tiling header, CMake, framework plugin, examples, tests) are present. Test coverage is actually more comprehensive than GT (2 test cases vs 1).

### C. Behavioral Equivalence: 3/5
Same fundamental algorithm (scale*x+shift, optional log(base) multiplication, exp). Key behavioral differences: (1) kernel function name differs; (2) float16 path casts to float32 while GT operates directly in float16; (3) BF16 cast uses CAST_ROUND vs GT's CAST_RINT (different rounding); (4) UB partition strategy differs (more conservative in generated); (5) no compile-time big/small core dispatch (uses runtime check instead). The generated test_exp.py is arguably more correct than GT's (GT has missing import and missing exp() call bugs).

### Verdict: **PARTIAL**
A=3 (< 4 threshold), B=4, C=3. The implementation demonstrates strong understanding of the AscendC programming model and CANN operator structure, with correct algorithm implementation and comprehensive file coverage. The main gaps are the kernel name mismatch and some implementation detail divergences that could affect runtime behavior.
