# Evaluation Report: C5-opencode-glm51-short-20260417

- **Task**: C5 — ReduceSumV2 custom operator for Ascend NPU (High complexity, C++, 25 HW files)
- **Config**: opencode-glm51-short
- **Evaluator**: claude-opus-4-6
- **Date**: 2026-04-18

---

## 1. File Coverage

| Metric | Value |
|--------|-------|
| HW files expected | 25 |
| Files generated | 3 |
| Files covered | 3 |
| **File coverage** | **12.0% (3/25)** |

### Covered Files
| File | Status |
|------|--------|
| src/math/reduce_sum_v2/op_host/reduce_sum_v2.cpp | Created (wrong content — contains tiling+InferShape instead of l0op wrapper) |
| src/math/reduce_sum_v2/op_host/reduce_sum_v2_def.cpp | Created (wrong API — attribute-based axis vs tensor-based axes) |
| src/math/reduce_sum_v2/op_host/reduce_sum_v2_tiling.h | Created (vastly oversimplified structure) |

### Missing Files (22)
- **Build**: CMakeLists.txt
- **Host**: aclnn_reduce_sum_v2.cpp, aclnn_reduce_sum_v2.h, fill.h, op_api_def.h, reduce_sum_v2_common.h, reduce_sum_v2_proto.cpp, reduce_sum_v2_proto.h, reduce_sum_v2_tiling.cpp, reduce_sum_v2.h
- **Kernel** (entire subsystem missing): reduce_sum_v2.cpp, reduce_sum_v2_ar.h, reduce_sum_v2_ara.h, reduce_sum_v2_common.h, kernel_utils.h
- **Examples** (entire subsystem missing): CMakeLists.txt, README.md, gen_data.py, main.cpp, run.sh, verify_result.py
- **Docs**: README.md

---

## 2. Function-Level Coverage

### reduce_sum_v2_def.cpp
| GT Element | Generated | Match |
|-----------|-----------|-------|
| Input "x" (6 dtype variants: BF16/FLOAT/FLOAT16 × 2 axes types) | Input "x" (4 variants: FLOAT16/FLOAT/BF16/INT32) | Partial — wrong dtype set, INT32 not in GT |
| Input "axes" (tensor, INT32/INT64) | **Missing** — uses Attr("axis").Int() instead | No |
| Output "y" (6 dtype variants) | Output "y" (4 variants) | Partial |
| Attr "keep_dims" (Optional, Bool) | Attr "keep_dims" (Optional, Bool) | Yes |
| Attr "noop_with_empty_axes" (Optional, Bool) | **Missing** | No |
| OpAICoreConfig (dynamic flags, extendCfgInfo) | **Missing** | No |
| AICore configs: ascend910b + ascend910_93 | Only ascend910b | Partial |

### reduce_sum_v2.cpp
| GT Element | Generated | Match |
|-----------|-----------|-------|
| l0op namespace with OP_TYPE_REGISTER | optiling namespace with TilingFunc | No — wrong purpose |
| IsAiCoreSupport() SoC check | N/A | No |
| ReduceSumV2AiCore() using ADD_TO_LAUNCHER_LIST_AICORE | N/A | No |
| ReduceSumV2() public l0op API | TilingFunc() + InferShapeForReduceSumV2() | No — different function |
| INFER_SHAPE macro, keepDim shape manipulation | InferShape implemented directly | Partial concept |

The generated reduce_sum_v2.cpp conflates tiling logic (which belongs in `reduce_sum_v2_tiling.cpp`) with shape inference (which belongs in `reduce_sum_v2_proto.cpp`) into one file. The GT's reduce_sum_v2.cpp is an l0op-level operator wrapper that dispatches to AICore.

### reduce_sum_v2_tiling.h
| GT Element | Generated | Match |
|-----------|-----------|-------|
| ReduceSumV2UbInfos (11 array fields) | **Missing** | No |
| ReduceSumV2BlockInfos (6 fields) | **Missing** | No |
| ReduceSumV2Process (8 fields + 3 sub-structs) | **Missing** | No |
| ReduceSumV2TilingData (processNum + 4 process structs) | ReduceSumV2TilingData (10 flat scalar fields) | No — completely different structure |
| ReduceSumV2CompileInfo struct | **Missing** | No |
| Includes: tiling_api.h, tiling_base.h, tiling_type.h | Only: tilingdata_base.h | Partial |

---

## 3. Semantic Analysis

### Architecture Mismatch
The GT implements a full operator stack with clear separation:
- **l0op layer** (`reduce_sum_v2.cpp`): Dispatches to AICore kernel
- **aclnn layer** (`aclnn_reduce_sum_v2.cpp`): Public API with validation, type promotion, contiguous conversion
- **Proto layer** (`reduce_sum_v2_proto.cpp`): Shape inference with tensor-based axes
- **Tiling layer** (`reduce_sum_v2_tiling.cpp`): Complex multi-process tiling with A/R/A1 pattern decomposition
- **Kernel layer** (`op_kernel/`): Ascend C kernel with aligned-reduce and atomic-reduce modes

The generated code collapses multiple layers into one file and misses the core computational layers entirely.

### Critical API Incompatibility
GT uses **tensor-based axes** (`Input("axes")` of type INT32/INT64), supporting multi-axis reduce with dynamic axes. The generated code uses **attribute-based axis** (`Attr("axis").Int()`), supporting only single-axis reduce with static axis. This is a fundamental interface mismatch — the generated operator would have a different signature and be unusable in the expected aclnn pipeline.

### Missing Kernel Implementation
The entire `op_kernel/` directory is absent. Without kernel code, no computation can execute on the Ascend NPU. The GT kernel includes:
- Aligned reduce mode (reduce_sum_v2_ara.h)
- Atomic reduce mode (reduce_sum_v2_ar.h)
- Common utilities (reduce_sum_v2_common.h, kernel_utils.h)
- Main kernel dispatch (reduce_sum_v2.cpp)

---

## 4. Scoring

| Dimension | Score | Rationale |
|-----------|-------|-----------|
| **A. Functional Correctness** | 1 | Code exists and identifies the correct task domain (ReduceSumV2 op registration, tiling data, shape inference). However: wrong API interface (attribute vs tensor axes), wrong file purposes (reduce_sum_v2.cpp serves a completely different role than GT), no kernel to execute any computation, would not compile in the CANN framework. Fundamental flaws prevent any functionality. |
| **B. Completeness & Coverage** | 1 | Minimal attempt: 3/25 files (12%). Entire subsystems missing: kernel (0/5), aclnn API (0/2), proto (0/2), build system (0/1), examples (0/6), documentation (0/1). The 3 files that exist serve different purposes than their GT counterparts. |
| **C. Behavioral Equivalence** | 0 | No behavioral similarity possible. No kernel exists to execute computation. The operator interface is incompatible (single attribute axis vs multi-axis tensor input). Tiling structure is fundamentally different (flat scalars vs nested multi-process). Even if assembled, would produce different results through a different API. |

### Verdict: **FAIL**
A=1 ≤ 1 → automatic FAIL.

The agent produced only 3 host-side files out of 25 required, with fundamental API mismatches and missing the entire compute kernel, aclnn API layer, build system, and examples. The C5 task is a High-complexity task requiring 25 files across multiple subsystems (kernel, host, aclnn, proto, tiling, examples); the generated output covers only the surface structure of op registration without the substance needed for a functional operator.
