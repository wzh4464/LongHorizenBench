# Evaluation Report: C4-claude-opus-max-short

**Evaluator**: claude-opus-4-6
**Task**: C4 — Implement Exp operator for Ascend NPU (cann-ops, Medium complexity, C++)
**Config**: Claude Code Opus max-effort, short prompt
**Date**: 2026-04-18

---

## Verdict: **PARTIAL**

## Scores

| Dimension | Score | Description |
|-----------|-------|-------------|
| A. Functional Correctness | 3 / 5 | Core operator logic correct; example/test don't exercise attributes |
| B. Completeness & Coverage | 3 / 5 | 18/19 HW files (case mismatch on docs/Exp.md); test content incomplete |
| C. Behavioral Equivalence | 3 / 5 | Same algorithm pipeline; differs in type widths, UB formula, attribute handling in examples |

---

## Deterministic Coverage

### HW File Coverage: 18 / 19 (94.7%)

| # | HW File | Status |
|---|---------|--------|
| 1 | src/contrib/math/exp/CMakeLists.txt | **Covered** |
| 2 | src/contrib/math/exp/README.md | **Covered** |
| 3 | src/contrib/math/exp/docs/Exp.md | **MISSING** (generated as `docs/exp.md` — case mismatch) |
| 4 | src/contrib/math/exp/examples/AclNNInvocationNaive/CMakeLists.txt | **Covered** |
| 5 | src/contrib/math/exp/examples/AclNNInvocationNaive/README.md | **Covered** |
| 6 | src/contrib/math/exp/examples/AclNNInvocationNaive/gen_data.py | **Covered** |
| 7 | src/contrib/math/exp/examples/AclNNInvocationNaive/main.cpp | **Covered** |
| 8 | src/contrib/math/exp/examples/AclNNInvocationNaive/run.sh | **Covered** |
| 9 | src/contrib/math/exp/examples/AclNNInvocationNaive/verify_result.py | **Covered** |
| 10 | src/contrib/math/exp/framework/CMakeLists.txt | **Covered** |
| 11 | src/contrib/math/exp/framework/tf_plugin/CMakeLists.txt | **Covered** |
| 12 | src/contrib/math/exp/framework/tf_plugin/tensorflow_exp_plugin.cc | **Covered** |
| 13 | src/contrib/math/exp/op_host/exp.cpp | **Covered** |
| 14 | src/contrib/math/exp/op_host/exp_tiling.h | **Covered** |
| 15 | src/contrib/math/exp/op_kernel/exp.cpp | **Covered** |
| 16 | src/contrib/math/exp/tests/st/Exp_case_alltype.json | **Covered** |
| 17 | src/contrib/math/exp/tests/st/README.md | **Covered** |
| 18 | src/contrib/math/exp/tests/st/msopst.ini | **Covered** |
| 19 | src/contrib/math/exp/tests/st/test_exp.py | **Covered** |

### Function/Symbol Coverage

GT defines ~25 key symbols; GEN covers ~23 with close equivalents.

| Key Symbol | GT | GEN | Match |
|-----------|-----|-----|-------|
| TilingFunc | `static ge::graphStatus TilingFunc(gert::TilingContext*)` | Same | Exact |
| InferShape | Present | Present | Exact |
| InferDataType | Not explicit | Present (extra) | GEN adds |
| KernelExp class | `template<TYPE_X, TYPE_Y, bool>` | `template<T, bool>` | Partial — single type param |
| Init/Process/CopyIn/Compute/CopyOut | Present | Present | Exact |
| Exp OpDef | `class Exp : public OpDef` | Same | Exact |
| Kernel entry | `void exp(...)` | `void exp_custom(...)` | Name differs |
| Host-side `_do` | `reciprocal_do` (GT copy-paste bug) | `exp_custom_do` | GEN is correct |
| gen_golden_data_simple | tests base/scale/shift | only tests e^x | Logic differs |
| calc_expect_func | `(x, base, scale, shift)` | `(x, y)` | Signature differs |
| exp_test | `(x, base, scale, shift)` | `(x)` — only tf.exp | Logic differs |
| verify_result | Custom tolerance | np.allclose | Equivalent |
| OP_ADD, REGISTER_CUSTOM_OP, REGISTER_TILING | Present | Present | Exact |

---

## Requirements Checklist

| Requirement | Status | Notes |
|-------------|--------|-------|
| Exp op computing y = base^(scale*x + shift) | **Partial** | Host/kernel implement full formula; example/test only exercise e^x |
| float16, float32, bfloat16 support | **Yes** | Op registered with all 3 types; kernel casts non-float32 to float32 |
| ND format support | **Yes** | Format defined in OpDef |
| base/scale/shift attributes | **Partial** | Defined in OpDef, handled in tiling/kernel; not passed in example main.cpp |
| Multi-core tiling (big/small core) | **Yes** | Correct big/small core splitting with tailBlockNum |
| AscendC kernel (Muls→Adds→Muls→Exp) | **Yes** | Pipeline correct; conditional optimizations for scale=1/shift=0 |
| Host tiling with UB partitioning | **Partial** | Present but formula differs (4:8 ratio vs GT's 3:2 based on bf16) |
| TF framework plugin | **Yes** | REGISTER_CUSTOM_OP with TENSORFLOW/AutoMappingByOpFn |
| Example (AclNNInvocationNaive) | **Partial** | main.cpp doesn't pass base/scale/shift to aclnn API |
| gen_data.py with reference computation | **Partial** | Only generates simple e^x data, not parameterized |
| ST test cases with all types | **Partial** | JSON missing attr section; test_exp.py only computes tf.exp(x) |
| Build system (CMakeLists) | **Yes** | Root + framework + example CMakeLists all correct |
| Documentation (README, docs/Exp.md) | **Partial** | docs file has wrong case; README content reasonable |

---

## Analysis

### Strengths
1. **Complete project structure**: All 19 HW files generated (with 1 case mismatch), correct directory layout matching cann-ops conventions
2. **Core algorithm correct**: op_host/exp.cpp correctly defines Exp with base/scale/shift attributes, tiling splits across big/small cores, computes base as ln(base) via logf
3. **Kernel pipeline correct**: op_kernel/exp.cpp implements the standard Muls→Adds→Muls→Exp computation with Cast for non-float32 types
4. **Proper op registration**: OpDef with 3 data types, 3 attributes, InferShape + InferDataType
5. **Fixed GT bugs**: GEN's kernel entry is `exp_custom` (correct convention) vs GT's `reciprocal_do` (copy-paste error from template)
6. **Identical files**: framework/CMakeLists.txt, framework/tf_plugin/CMakeLists.txt, msopst.ini are byte-identical to GT

### Weaknesses
1. **File case mismatch**: `docs/exp.md` (lowercase) vs GT's `docs/Exp.md` (uppercase) — would not be found by case-sensitive tooling
2. **Example doesn't exercise attributes**: main.cpp calls `aclnnExpGetWorkspaceSize(inputX, outputY, ...)` without base/scale/shift — won't work for non-default attribute values
3. **gen_data.py oversimplified**: Only tests `np.exp(x)` with shape [32], not the full `base^(scale*x + shift)` with GT's shape [10,10] and specific parameters
4. **test_exp.py incomplete**: `calc_expect_func(x, y)` only does `tf.exp(x["value"])` — doesn't handle attributes, wrong key name (`"value"` vs GT's `"x"`)
5. **Exp_case_alltype.json missing attrs**: No attr section for base/scale/shift — only tests default natural exp
6. **Type width difference**: Tiling data uses `uint32_t` vs GT's `uint64_t` — may overflow on very large tensors
7. **UB partitioning formula**: `ubPartNum = (dataTypeLength == 4) ? 4 : 8` vs GT's `(dt == DT_BF16) ? 3 : 2` with BUFFER_NUM — different memory utilization
8. **logf in kernel**: GEN computes `logf(this->base)` inside `__aicore__` function; GT precomputes in host tiling — potential issue for NPU deployment since standard C library functions may not be available in device code

### Key Behavioral Differences
- **Core operator**: Mathematically equivalent for all cases (natural exp and parameterized exp)
- **Example behavior**: GEN tests only e^x; GT tests base=2, scale=2, shift=1 with 10×10 shape
- **Test validation**: GEN validates simple exp; GT validates parameterized formula (though GT's test_exp.py also has a bug — missing final np.exp() call)
- **Memory layout**: Different UB partition strategies would produce different performance characteristics on hardware

---

## Confidence

**Medium-High (75%)**. The core operator implementation (host + kernel) is functionally correct and would produce correct results for the Exp computation. The main gaps are in the example and test infrastructure, which don't exercise the full attribute-parameterized behavior. The file case mismatch is a minor but definite issue. UB partitioning differences and type width choices could affect correctness on edge cases with very large tensors.
